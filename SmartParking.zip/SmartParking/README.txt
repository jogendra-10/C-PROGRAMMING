SMART PARKING SLOT ALLOCATION AND BILLING SYSTEM  (C project)

FILES
  parking.c            the whole program (4 modules, commented)
  .vscode/tasks.json   lets VS Code build the program with Ctrl+Shift+B

HOW TO RUN IN VS CODE
  1. Unzip the folder, then in VS Code: File > Open Folder > SmartParking
  2. Make sure GCC is installed (Windows: MinGW / MSYS2, Mac: xcode-select --install,
     Linux: sudo apt install gcc)
  3. Open the Terminal in VS Code (Ctrl + `) and type:
         gcc parking.c -o parking
         ./parking          (on Windows PowerShell: .\parking)
     OR press Ctrl+Shift+B to build, then run the program in the terminal.

TIPS
  - Type vehicle numbers with no spaces (example: TN09AB1234)
  - Vehicle types: 1 = Bike (Rs.10/hr), 2 = Car (Rs.20/hr), 3 = Heavy (Rs.40/hr)
  - Hours use the 24-hour clock (0 to 23)
  - history.txt is created automatically after the first vehicle exits.
    Delete it to clear all history.

SAMPLE TEST (matches slide 19)
  Park TN09AB1234 car   at 9,  TN22CD5678 bike at 10, TN01EF9012 heavy at 11
  Exit them at 12, 12 and 15 -> fees 60, 20, 160 -> total Rs. 240
